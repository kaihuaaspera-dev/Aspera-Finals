import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_model.dart';

class AuthController {
  final SupabaseClient _supabase = Supabase.instance.client;

  // Register a new user
  Future<void> register(String fullName, String email, String password) async {
    try {
      await _supabase.auth.signUp(
        email: email,
        password: password,
        data: {'full_name': fullName}, // Stored in metadata for the SQL Trigger
      );
    } catch (e) {
      rethrow;
    }
  }

  // Login existing user
  Future<void> login(String email, String password) async {
    try {
      await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      rethrow;
    }
  }

  // Logout user
  Future<void> logout() async {
    try {
      await _supabase.auth.signOut();
    } catch (e) {
      rethrow;
    }
  }

  // Fetch the authenticated user's profile data
  Future<UserModel?> getUserProfile() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return null;

      final response =
          await _supabase.from('profiles').select().eq('id', user.id).single();

      return UserModel.fromJson(response);
    } catch (e) {
      // Return null or handle error if profile fetch fails
      return null;
    }
  }
}
