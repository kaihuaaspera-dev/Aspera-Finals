package com.example.ccs3800_midterm

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
