package com.example.flutter_mvc_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
