// lib/controllers/calculator_controller.dart

import '../models/calculator_model.dart';

class CalculatorController {
  // Initialize the model
  final CalculatorModel _model = CalculatorModel();

  String calculate(String input1, String input2, String operation) {
    // Handle empty inputs
    if (input1.trim().isEmpty || input2.trim().isEmpty) {
      return "Please enter both numbers.";
    }

    // Convert inputs to numbers
    double? num1 = double.tryParse(input1);
    double? num2 = double.tryParse(input2);

    // Handle invalid numbers (e.g., user types letters)
    if (num1 == null || num2 == null) {
      return "Invalid numbers.";
    }

    double result;

    // Perform operation
    try {
      switch (operation) {
        case 'add':
          result = _model.add(num1, num2);
          break;
        case 'subtract':
          result = _model.subtract(num1, num2);
          break;
        case 'multiply':
          result = _model.multiply(num1, num2);
          break;
        case 'divide':
          // Handle division by zero
          if (num2 == 0) {
            return "Cannot divide by zero.";
          }
          result = _model.divide(num1, num2);
          break;
        default:
          return "Unknown operation.";
      }

      // Format the result (removes trailing .0 for whole numbers)
      if (result == result.toInt()) {
        return result.toInt().toString();
      }
      return result.toString();
    } catch (e) {
      return "Error during calculation.";
    }
  }
}
