// lib/models/calculator_model.dart

class CalculatorModel {
  double add(double a, double b) {
    return a + b;
  }

  double subtract(double a, double b) {
    return a - b;
  }

  double multiply(double a, double b) {
    return a * b;
  }

  double divide(double a, double b) {
    // The controller usually catches the zero division,
    // but the model should still protect against it.
    if (b == 0) {
      throw Exception("Cannot divide by zero.");
    }
    return a / b;
  }
}
