// lib/views/calculator_view.dart

import 'package:flutter/material.dart';
import '../controllers/calculator_controller.dart'; // Import the controller

class CalculatorView extends StatefulWidget {
  const CalculatorView({super.key});

  @override
  State<CalculatorView> createState() => _CalculatorViewState();
}

class _CalculatorViewState extends State<CalculatorView> {
  final TextEditingController number1Controller = TextEditingController();
  final TextEditingController number2Controller = TextEditingController();

  // 1. Initialize the Controller
  final CalculatorController _calculatorController = CalculatorController();

  String result = "";

  // 2. Create a helper method to handle calculations
  void _handleCalculation(String operation) {
    setState(() {
      // Pass the text values and the operation to the controller
      result = _calculatorController.calculate(
        number1Controller.text,
        number2Controller.text,
        operation,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("MVC Calculator")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: number1Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "First Number",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: number2Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Second Number",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 30),
            Text(
              "Result: $result",
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // 3. Connect the Add button
                ElevatedButton(
                  onPressed: () => _handleCalculation('add'),
                  child: const Text("Add"),
                ),

                // 4. Connect the Subtract button
                ElevatedButton(
                  onPressed: () => _handleCalculation('subtract'),
                  child: const Text("Subtract"),
                ),
              ],
            ),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // 5. Connect the Multiply button
                ElevatedButton(
                  onPressed: () => _handleCalculation('multiply'),
                  child: const Text("Multiply"),
                ),

                // 6. Connect the Divide button
                ElevatedButton(
                  onPressed: () => _handleCalculation('divide'),
                  child: const Text("Divide"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
